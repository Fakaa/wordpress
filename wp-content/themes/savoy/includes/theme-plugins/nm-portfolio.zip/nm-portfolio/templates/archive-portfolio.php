<?php
global $nm_theme_options;

get_header(); ?>

<div class="nm-page-full">
    
    <?php
    if ( isset( $nm_theme_options['portfolio_page_id'] ) && strlen( $nm_theme_options['portfolio_page_id'] ) > 0 ) :
        $portfolio_page = get_post( apply_filters( 'wpml_object_id', $nm_theme_options['portfolio_page_id'], 'portfolio' ) ); // WPML: The "wpml_object_id" filter is used to get the translated    
    
        if ( $portfolio_page ) :
            $portfolio_page_content = apply_filters( 'the_content', $portfolio_page->post_content );
    ?>
        
        <div id="post-<?php $portfolio_page->ID; ?>" <?php post_class( 'entry-content' ); ?>>
            <?php echo $portfolio_page_content; ?>
        </div>
        
        <?php endif; ?>
    
    <?php else: ?>
    
    <div class="nm-row">
        <div class="col-xs-12">
            <p class="nm-portfolio-page-not-set"><?php esc_html_e( 'Please select the default Portfolio page on the "Theme Settings &rarr; Portfolio" page in the WordPress admin.', 'nm-portfolio' ); ?></p>
        </div>
    </div>
        
    <?php endif; ?>
    
</div>

<?php get_footer(); ?>