<?php
	
	// Shortcode: nm_portfolio
	function nm_shortcode_portfolio( $atts, $content = NULL ) {
		global $post, $wp_query;
		
		nm_add_page_include( 'portfolio' );
		
		extract( shortcode_atts( array(
			'filters'			=> '1',
			'filters_alignment'	=> 'left',
			'items'				=> '',
			'columns'			=> '2',
			'category'			=> '',
			'ids'				=> '',
			'order_by'			=> 'date',
			'order'				=> 'desc',
			'layout'			=> 'standard',
			'packery'			=> '1'
		), $atts ) );
		
		// Assets
		wp_enqueue_script( 'nm-portfolio', NM_PORTFOLIO_URI . 'assets/js/nm-portfolio.min.js', array( 'jquery', 'packery' ), NM_PORTFOLIO_VERSION );
		
		// Packery
		if ( $packery == '1' ) {
			wp_enqueue_script( 'packery', NM_THEME_URI . '/js/plugins/packery.pkgd.min.js', array(), '1.3.2', true );
			
			$packery_class = ' packery-enabled';
			$loader_class = ' nm-loader';
		} else {
			$packery_class = $loader_class = '';
		}
		
		$category_slug = str_replace( '_', '-', $category );
		$posts_per_page = ( strlen( $items ) > 0 ) ? intval( $items ) : -1;
		
		// Post type query args
		$args = array(
			'post_type' 			=> 'portfolio',
			'post__in'				=> '',
			'post_status' 			=> 'publish',
			'portfolio-category'	=> $category_slug,
			'posts_per_page'		=> $posts_per_page,
			'ignore_sticky_posts'	=> 1,
			/*'tax_query' => array(
				array(
					'taxonomy'	=> 'portfolio-category',
					'field' 	=> 'id',
					'terms' 	=> array( $exclude_categories ),
					'operator'	=> 'NOT IN'
				)
			),*/
			'order_by'				=> $order_by,
			'order'					=> $order
		);
		
		// If Post IDs
		if ( $ids ) {
			$posts_in = array_map( 'intval', explode( ',', $ids ) );
			$args['post__in'] = $posts_in;
		}
		
		// Post type query
		$portfolio = new WP_Query( $args );
		
		// Image overlay
		$image_overlay = ( $layout != 'overlay' ) ? '<div class="nm-image-overlay"></div>' : '';
				
		$output = '';
		
		while ( $portfolio->have_posts() ) : $portfolio->the_post();
			
			// Get post meta
			$portfolio_meta = get_post_meta( $post->ID, 'nm_portfolio_post_type_meta', true );
			
			// Image
			$image_id = get_post_thumbnail_id();
			if ( $image_id ) {
				$image_src = wp_get_attachment_image_src( $image_id, 'full' );
				$image = '<img src="' . esc_url( $image_src[0] ) . '" />';
			} else {
				$image = '<span class="nm-img-placeholder"></span>';
			}
			
			// Text color class (used for overlay layout)
			$text_color_class = ( isset( $portfolio_meta['overlay_text_color'] ) ) ? ' text-color-' . $portfolio_meta['overlay_text_color'] : '';
			
			// Item categories
			$item_categories = get_the_terms( get_the_ID(), 'portfolio-category' );
			$item_categories_class = '';
			$item_categories_output = '';
			
			if ( ! empty( $item_categories ) ) {
				foreach( $item_categories as $item_category ) {
					$item_categories_class .= $item_category->slug . ' ';
					$item_categories_output .= $item_category->name . '<span>, </span>';
				}
				
				$item_categories_class = ' class="' . esc_attr( $item_categories_class ) . '"';
			}
			
			// Item markup
			$output .= '
				<li' . $item_categories_class . '>
					<a href="' . get_permalink() . '">
						<div class="nm-portfolio-item-image">' .
							$image .
							$image_overlay . '
						</div>
						
						<div class="nm-portfolio-item-details' . esc_attr( $text_color_class ) . '">' .
							the_title( '<h2>', '</h2>', false ) . '
							<p>' . $item_categories_output . '</p>
						</div>
					</a>
				</li>';
		
		endwhile;
			
		wp_reset_postdata();
		
		// Filters menu
		if ( $filters == '1' ) {
			$args = array(
				'type'			=> 'post',
				'orderby'		=> 'name',
				'order'			=> 'ASC',
				'hide_empty'	=> 0,
				'hierarchical'	=> 1,
				'taxonomy'		=> 'portfolio-category'
			);
			$categories = get_categories( $args );
			$filters_menu = '';
			
			foreach ( $categories as $category ) {
				$filters_menu .= '<li><span>&frasl;</span><a href="#" data-filter="' . esc_attr( $category->slug ) . '">' . esc_html( $category->name ) . '</a></li>';
			}
			$filters_menu = '<ul class="nm-portfolio-filters align-' . esc_attr( $filters_alignment ) . '"><li class="current"><a href="#">' . __( 'All', 'nm-portfolio' ) . '</a></li>' . $filters_menu . '</ul>';
		} else {
			$filters_menu = '';
		}
		
		// Output
		$output = '
			<div class="nm-portfolio layout-' . esc_attr( $layout ) . $packery_class . '">' .
				$filters_menu . '
				
				<ul class="nm-portfolio-grid small-block-grid-1 medium-block-grid-2 large-block-grid-' . esc_attr( $columns ) . $loader_class . '">' .
					$output . '
				</ul>
			</div>';
			
		return $output;
	}
	
	add_shortcode( 'nm_portfolio', 'nm_shortcode_portfolio' );
	